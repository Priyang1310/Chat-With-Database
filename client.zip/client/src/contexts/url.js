const backend_url = "http://localhost:7000"

export {backend_url}