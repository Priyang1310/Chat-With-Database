import React from 'react'
import Main from './sections/chatbot'
import { Router } from './routes/sections'

const App = () => {
  return (
      <Router />
  )
}

export default App